package com.example.demoForCollege.Service;

import com.example.demoForCollege.entity.Appointment;
import com.example.demoForCollege.entity.User;

import jakarta.transaction.Transactional;

import com.example.demoForCollege.Repository.AppointmentRepo;
import com.example.demoForCollege.Repository.UserRepo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AppointmentService {
	  @Autowired
	    private UserRepo userRepo;

	    public User findUserById(Long userId) {
	        return userRepo.findById(userId)
	            .orElseThrow(() -> new RuntimeException("User not found with ID: " + userId));
	    }
    @Autowired
    private AppointmentRepo appointmentRepository;

    // Book an appointment
    public Appointment bookAppointment(Appointment appointment) {
        return appointmentRepository.save(appointment);
    }

    // Get all appointments for a student
    public List<Appointment> getAppointmentsByStudentId(Long studentId) {
        return appointmentRepository.findByStudentId(studentId);
    }

    // Get all appointments for a professor
    public List<Appointment> getAppointmentsByProfessorId(Long professorId) {
        return appointmentRepository.findByProfessorId(professorId);
    }

    public List<Appointment> getAppointmentsByProfessorAndTimeSlot(Long professorId, String timeSlot) {
        return appointmentRepository.findByProfessorIdAndTimeSlot(professorId, timeSlot);
    }

    public List<Appointment> getAppointmentsByStudentAndTimeSlot(Long studentId, String timeSlot) {
        return appointmentRepository.findByStudentIdAndTimeSlot(studentId, timeSlot);
    }

    // Cancel an appointment by student ID
    @Transactional
    public void deleteAppointmentByStudentId(Long studentId) {
        appointmentRepository.deleteByStudentId(studentId);
    }
    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

	
}
//@Service
//public class AppointmentService {
//
//	@Autowired
//	private AppointmentRepo appointmentRepository;
//
//	// Book an appointment
//	public Appointment bookAppointment(Appointment appointment) {
//
//		return appointmentRepository.save(appointment);
//	}
//
//	// Get all appointments for a user
//	public List<Appointment> getAppointmentsByUserId(Long id) {
//		return appointmentRepository.findByUser_Id(id);
//	}
//
//	// Get all appointments for a professor
//	public List<Appointment> getAppointmentsByProfessorId(Long professorId) {
//		return appointmentRepository.findByProfessorId(professorId);
//	}
//
//	public List<Appointment> getAppointmentsByProfessorAndTimeSlot(Long professorId, String timeSlot) {
//		return appointmentRepository.findByProfessorIdAndTimeSlot(professorId, timeSlot);
//	}
//
//	public List<Appointment> getAppointmentsByStudentAndTimeSlot(Long studentId, String timeSlot) {
//		return appointmentRepository.findByStudentIdAndTimeSlot(studentId, timeSlot);
//	}
//
//	// Cancel an appointment
//	public void cancelAppointment(Long appointmentId) {
//		appointmentRepository.deleteById(appointmentId);
//
//	}
//
//	// Delete availability
//	@Transactional
//	public void deleteAppointment(Long studentId) {
//		appointmentRepository.deleteByStudentId(studentId);
//	}
//
//}
