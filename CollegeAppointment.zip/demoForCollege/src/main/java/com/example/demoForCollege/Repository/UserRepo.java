package com.example.demoForCollege.Repository;

import com.example.demoForCollege.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;
import java.util.Optional;
@Repository
public interface UserRepo extends JpaRepository<User, Long> {

	
	Optional<User> findById(Long id);
//	public static Optional<User> findById(Long userId) {
//	    try {
//	        // Assuming you're using a repository to find the User by id, like a Spring Data JPA repository
//	        Optional<User> userOptional = findById(userId);  // Replace userRepository with your actual repository
//
//	        // Return the Optional from the repository call
//	        return userOptional;
//
//	    } catch (Exception e) {
//	        // Log the error (you can use any logging framework, for example, SLF4J)
//	        // Log.error("Error fetching user with ID: " + userId, e);
//
//	        // Optionally, rethrow the exception or return an empty Optional
//	        throw new RuntimeException("Error fetching user with ID: " + userId, e);
//	    }
//	
//	}

	Optional<UserRepo> findByRole(String role);

	Optional<User> findByUsername(String username);

}