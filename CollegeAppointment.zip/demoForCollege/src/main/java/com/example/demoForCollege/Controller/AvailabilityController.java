
package com.example.demoForCollege.Controller;

import com.example.demoForCollege.entity.Availability;
import com.example.demoForCollege.Service.AvailabilityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import java.util.Map;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/availability")
public class AvailabilityController {

    @Autowired
    private AvailabilityService availabilityService;
  
        @PostMapping("/set")
        public ResponseEntity<String> createAvailability(@RequestBody Map<String, Object> requestBody) {
            try {
                Long professorId = Long.valueOf(requestBody.get("professorId").toString());
                String timeSlot = requestBody.get("timeSlot").toString();
                String status = requestBody.get("status").toString();

                Availability availability = new Availability();
                availability.setProfessorId(professorId);
                availability.setTimeSlot(timeSlot);
                availability.setStatus(status);

                availabilityService.createAvailability(professorId,timeSlot,status);
                return ResponseEntity.status(HttpStatus.CREATED).body("Availability set successfully");
            } catch (Exception e) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: " + e.getMessage());
            }
        }

      
        @GetMapping("/professor/{professorId}")
        public ResponseEntity<List<Availability>> getAvailabilityByProfessorId(@PathVariable Long professorId) {
            List<Availability> availabilityList = availabilityService.getAvailabilityByProfessorId(professorId);
            return ResponseEntity.ok(availabilityList);
        }

       

    }

  