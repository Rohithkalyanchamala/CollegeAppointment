package com.example.demoForCollege.Service;

import com.example.demoForCollege.entity.Availability;
import com.example.demoForCollege.entity.User;
import com.example.demoForCollege.Repository.AvailabilityRepo;
import com.example.demoForCollege.Repository.UserRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;
import java.util.List;

@Service
public class AvailabilityService {

	@Autowired
	private AvailabilityRepo availabilityRepo;

	@Autowired
	private UserRepo userRepo;

	public Availability createAvailability(Long professorId, String timeSlot, String status) {

		Availability availability = new Availability();
		availability.setProfessorId(professorId);
		availability.setTimeSlot(timeSlot);
		availability.setStatus(status);

		return availabilityRepo.save(availability);
	}

	public List<Availability> getAvailabilityByProfessorId(Long professorId) {
		return availabilityRepo.findByProfessorId(professorId);
	}

	public void deleteAvailability(Long availabilityId) {
		availabilityRepo.deleteById(availabilityId);
	}

}
