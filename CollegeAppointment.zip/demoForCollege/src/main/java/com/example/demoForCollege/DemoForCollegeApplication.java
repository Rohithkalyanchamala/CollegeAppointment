package com.example.demoForCollege;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.example.demoForCollege.entity")
public class DemoForCollegeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoForCollegeApplication.class, args);
	}

}
