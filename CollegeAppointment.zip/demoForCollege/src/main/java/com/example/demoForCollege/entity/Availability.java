package com.example.demoForCollege.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import org.antlr.v4.runtime.misc.NotNull;

import jakarta.persistence.Column;




@Entity
public class Availability {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;  // Primary key
  
    
    
    @Column(nullable = false)
    private String timeSlot;
    
    @Column(nullable = false)
    private String status;
    
    @Column(nullable = false)
    private Long professorId;
   


    public Availability() {}
    
    

   
    public Availability( String timeSlot,String status, Long professorId) {
        this.professorId=professorId;
        this.timeSlot = timeSlot;
        this.status= status;
    }

   
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public Long getProfessorId() {
		return professorId;
	}

	public void setProfessorId(Long professorId) {
		this.professorId = professorId;
	}

    public String getTimeSlot() {
        return timeSlot;
    }

    public void setTimeSlot(String timeSlot) {
        this.timeSlot = timeSlot;
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}