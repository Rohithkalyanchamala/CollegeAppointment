package com.example.demoForCollege.Controller;

import com.example.demoForCollege.entity.Appointment;
import com.example.demoForCollege.entity.User;
import com.example.demoForCollege.Repository.UserRepo;
import com.example.demoForCollege.Service.AppointmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/appointment")
public class AppointmentController {

    @Autowired
    private AppointmentService appointmentService;

    @PostMapping("/book")
    public ResponseEntity<String> bookAppointment(@Validated @RequestBody Appointment appointment) {
        if (appointment.getTimeSlot() == null || appointment.getTimeSlot().isEmpty()) {
            return ResponseEntity.badRequest().body("Error: Time slot cannot be null or empty");
        }

        String timeSlot = appointment.getTimeSlot().toUpperCase();
        if (!timeSlot.equals("MORNING") && !timeSlot.equals("EVENING")) {
            return ResponseEntity.badRequest().body("Error: Invalid time slot value. Please use 'MORNING' or 'EVENING'");
        }
        if (appointment.getStudentId() == null || appointment.getProfessorId() == null) {
            return ResponseEntity.badRequest().body("Error: Both studentId and professorId are required to be NotNull.");
        }
      
        if (appointment.getUser() == null) {
            return ResponseEntity.badRequest().body("Error: userId is required.");
        }

        try {
        	
        	 Long userId = appointment.getUser().getId();  // Get the user ID from the appointment object
             
             // Find the user by ID
             User user = appointmentService.findUserById(userId);
             
             // Continue with your appointment booking logic...
             // Set user in appointment
             appointment.setUser(user);
        	
        	 
                      
        	
        	 appointment.setUser(user);
            appointment.setTimeSlot(timeSlot);
            appointmentService.bookAppointment(appointment);
            return ResponseEntity.status(HttpStatus.CREATED).body("Appointment booked successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Error: " + e.getMessage());
        }
    }

//    @GetMapping("/student/{studentId}")
//    public ResponseEntity<List<Appointment>> getAppointmentsByStudentId(@PathVariable Long studentId) {
//        List<Appointment> appointments = appointmentService.getAppointmentsByStudentId(studentId);
//        return ResponseEntity.ok(appointments);
//    }
    
    @GetMapping("/student/{studentId}")
    public ResponseEntity<?> getAppointmentsByStudentId(@PathVariable Long studentId) {
        List<Appointment> studentAppointments = appointmentService.getAppointmentsByStudentId(studentId);

        if (studentAppointments.isEmpty()) {
            // Check if other appointments exist
            List<Appointment> allAppointments = appointmentService.getAllAppointments();
            if (!allAppointments.isEmpty()) {
                return ResponseEntity.ok("Your appointment was cancelled by the Professor");
            } else {
                return ResponseEntity.ok("No appointments found");
            }
        }

        // Return the student's appointments if they exist
        return ResponseEntity.ok(studentAppointments);
    }

    
    

    @GetMapping("/professor/{professorId}")
    public ResponseEntity<List<Appointment>> getAppointmentsByProfessorId(@PathVariable Long professorId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByProfessorId(professorId);
        return ResponseEntity.ok(appointments);
    }

    @DeleteMapping("/remove/{studentId}")
    public ResponseEntity<String> deleteAppointment(@PathVariable Long studentId) {
        appointmentService.deleteAppointmentByStudentId(studentId);
        return ResponseEntity.ok("Appointment deleted successfully");
    }
}