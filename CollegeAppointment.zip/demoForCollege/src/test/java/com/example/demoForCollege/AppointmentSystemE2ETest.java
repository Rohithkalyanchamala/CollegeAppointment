package com.example.demoForCollege;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.awt.PageAttributes.MediaType;

@SpringBootTest
@TestMethodOrder(OrderAnnotation.class)
@AutoConfigureMockMvc
public class AppointmentSystemE2ETest {

	@Autowired
	private MockMvc mockMvc;
	private String professorP1Token;
	private String studentA1Token;
	private String studentA2Token;
	@Test
	@Order(1)
	//Student A1 authenticates to access the system.
	void testStudentLogin() throws Exception{
		
		
	MvcResult studentA1Login = mockMvc.perform(post("http://localhost:9999/api/user/authenticate")
				.content("{\"username\": \"A1\", \"password\": \"password123\"}").contentType("application/json"))
				.andExpect(status().isOk()).andReturn();
	String responseBody = studentA1Login.getResponse().getContentAsString();
    System.out.println("Student A1 Login Response: " + responseBody);
    
    studentA1Token = extractToken(responseBody);
    }

    private String extractTokenStud1(String responseBody) {
        // Assuming the token is in the format {"token": "your-token-value"}
        return responseBody.replaceAll(".*\"token\":\\s*\"([^\"]+)\".*", "$1");
    }
    @Test
    @Order(2)
    //Professor P1 authenticates to access the system.
	void testProfessorLogin() throws Exception {
		
	MvcResult professorP1Login = mockMvc.perform(post("http://localhost:9999/api/user/authenticate")
				.content("{\"username\": \"P1\", \"password\": \"password123\"}").contentType("application/json"))
				.andExpect(status().isOk()).andReturn();	
		String responseBody = professorP1Login.getResponse().getContentAsString();
	    System.out.println("Professor Login Response: " + responseBody);
		
	    professorP1Token = extractToken(responseBody);
	    }

	    private String extractToken(String responseBody) {
	        // Assuming the token is in the format {"token": "your-token-value"}
	        return responseBody.replaceAll(".*\"token\":\\s*\"([^\"]+)\".*", "$1");
	    }
	
	
	
	    @Test
	    @Order(3)
		//  Professor P1 specifies which time slots he is free for appointments- Set Availability
        void setAvailability() throws Exception { 
		
     	// Professor P1 specifies available time slots
        	MvcResult setAvailability = mockMvc.perform(post("http://localhost:9999/api/availability/set")
						.content("{ \"professorId\": 1,\"timeSlot\": \"MORNING\",\"status\": \"active\"}")
						.contentType("application/json"))
				.andExpect(status().isOk()).andReturn();
		String responseBody = setAvailability.getResponse().getContentAsString();
		System.out.println("Availability set Response: " + responseBody);
		}
		
		
        @Test
        @Order(4)
         //  Professor P1 specifies which time slots he is free for appointments- Set Availability
        void setAvailability2() throws Exception { 

	    // Professor P1 specifies available time slots
	     MvcResult setAvailability = mockMvc.perform(post("http://localhost:9999/api/availability/set")
				.content("{ \"professorId\": 1,\"timeSlot\": \"EVENING\",\"status\": \"active\"}")
				.contentType("application/json"))
		.andExpect(status().isOk()).andReturn();
         String responseBody = setAvailability.getResponse().getContentAsString();
          System.out.println("Availability set Response: " + responseBody);
         
          }
        
        @Test
        @Order(5)
        void checkSlots() throws Exception {
            // Student A1 views available time slots for Professor P1
            mockMvc.perform(get("http://localhost:9999/api/availability/professor/{professorId}", 1) // Assuming 22 is the professorId
                    .header("Authorization", "Bearer " + studentA1Token))
                    .andExpect(status().isOk())
                    .andExpect(jsonPath("$[0].timeSlot").value("MORNING")) // Accessing the first slot
                    .andExpect(jsonPath("$[1].timeSlot").value("EVENING")) // Accessing the second slot
                    .andReturn();
            System.out.println();        }
        
        @Test
        @Order(6)
        void bookAppointment( ) throws Exception{
		// Student A1 books an appointment with Professor P1 for time T1
	 MvcResult bookAppointment =	mockMvc.perform(post("http://localhost:9999/api/appointment/book")
				.content("{"
	                    + "\"user\": {"
	                    + "\"id\": 26,"
	                    + "\"username\": \"A1\","
	                    + "\"password\": \"password123\","
	                    + "\"role\": \"student\""
	                    + "},"
	                    + "\"professorId\": 1,"
	                    + "\"studentId\": 21,"
	                    + "\"timeSlot\": \"MORNING\""
	                    + "}")
				.contentType("application/json"))
			    .andExpect(status().isOk())
				.andReturn();
	 String responseBody = bookAppointment.getResponse().getContentAsString();
	 
	    System.out.println("Appointment Booking Response: " + responseBody);
}
        @Test
        @Order(7)
    	//Student A2 authenticates to access the system.
    	void testStudentLogin2() throws Exception{
    		
    		
    	MvcResult studentA2Login = mockMvc.perform(post("http://localhost:9999/api/user/authenticate")
    				.content("{\"username\": \"A2\", \"password\": \"password123\"}").contentType("application/json"))
    				.andExpect(status().isOk()).andReturn();
    	String responseBody = studentA2Login.getResponse().getContentAsString();
        System.out.println("Student A2 Login Response: " + responseBody);
        
        
        studentA2Token = extractToken(responseBody);
        }

        private String extractTokenStud2(String responseBody) {
            return responseBody.replaceAll(".*\"token\":\\s*\"([^\"]+)\".*", "$1");
        }
        
        @Test
        @Order(8)
        void bookAppointment2( ) throws Exception{
		// Student A1 books an appointment with Professor P1 for time T1
	 MvcResult bookAppointment =	mockMvc.perform(post("http://localhost:9999/api/appointment/book")
				.content("{"
	                    + "\"user\": {"
	                    + "\"id\": 27,"
	                    + "\"username\": \"A2\","
	                    + "\"password\": \"password123\","
	                    + "\"role\": \"student\""
	                    + "},"
	                    + "\"professorId\": 1,"
	                    + "\"studentId\": 22,"
	                    + "\"timeSlot\": \"EVENING\""
	                    + "}")
				.contentType("application/json"))
			    .andExpect(status().isOk())
				.andReturn();
	      String responseBody = bookAppointment.getResponse().getContentAsString();
	 
	    System.out.println("Appointment Booking Response: " + responseBody);
}
     
     @Test
     @Order(9)
      // Professor P1 cancels the appointment with Student A1
       void deleteAppointment() throws Exception {
    	 System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
      mockMvc.perform(delete("http://localhost:9999/api/appointment/remove/21") // Pass studentId as a path variable
              .header("Authorization", "Bearer " + professorP1Token)) // Include the Authorization header
              .andExpect(status().isOk()) // Expect HTTP 200 OK
              .andExpect(content().string("Appointment deleted successfully")); // Check plain string response
  }

  
     @Test
     @Order(10)
     void recheckAppointments() throws Exception {
         // Student A1 checks their appointments
         try {
             // Perform the GET request to fetch appointments for student ID 21
             MvcResult result = mockMvc.perform(get("http://localhost:9999/api/appointment/student/21")
                     .header("Authorization", "Bearer " + studentA1Token))  // Assuming token is correct
                     .andExpect(status().isOk()) // Ensure the status is OK (200)
                     .andReturn(); // Capture the result
             
             // Extract the response content
             String responseContent = result.getResponse().getContentAsString();
             
             // Print out the response content for debugging purposes
             System.out.println("Response Content: " + responseContent);
             
             // Check if the response contains appointment data
             if (responseContent != null && !responseContent.trim().isEmpty()) {
                 // Parse the response if needed (ensure the response is a valid JSON with appointments)
                 // If no appointments are found, return a message
                 if (responseContent.contains("appointments") && responseContent.equals("[]")) {
                     System.out.println("No appointments found for student ID 21.");
                 } else {
                     System.out.println("Appointments found: " + responseContent);
                 }
             } else {
                 System.out.println("No appointment data found in response.");
             }

         } catch (Exception e) {
             // If an exception occurs, log the error
             System.err.println("Error occurred while checking appointments: " + e.getMessage());
         }
     }

}
